import time
from options.train_options import TrainOptions
from data.data_loader import DataLoader
from models.cyclegan_model import Cyclegan
from utils import ddp
from tqdm import tqdm
import os
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"

def run(opt):

    dataset = DataLoader(opt) 
    print("# training images {}".format(len(dataset)*opt.batchsize))
    # for loading test dataset
    test_opt = opt
    test_opt.isTrain = False
    test_opt.phase = 'test' 
    
    test_dataset = DataLoader(test_opt)
    print("# testing images {}".format(len(test_dataset)*test_opt.batchsize))
    
    model = Cyclegan(opt)
    
    for epoch in range(opt.start_epoch, opt.n_epochs):
        epoch_start_time = time.time()
        pbar = tqdm(dataset, desc= 'Batch Running', unit="batch", disable=not ddp.is_main_process())
        # update learning rate
        model.update_learning_rate(epoch)
        
        for i, data  in enumerate(pbar):
            
            model.set_input(data) # calculate all the inputs/ outputs    
            model.optimize_parameters() # update parameters
            
            if i % opt.display_freq == 0 and i > 1:
                model.get_current_losses(epoch, i, len(dataset),  epoch_vis=False, test_dataset=None)
        # save model for each epoch
        print(('Total elapsed time for epoch:' , time.time() - epoch_start_time))
        model.model_save(epoch+1)
        # vis epoch losses
        model.get_current_losses(epoch, i, len(dataset), epoch_vis=True, test_dataset=test_dataset) # includes testing results if test dataset is not None.
        model.initialize_training()

if __name__ == '__main__':
    # for ddp
    #torchrun --nnodes=1 --nproc-per-node=4 main.py --distributed
    # for ddp & wandb
    #torchrun --nnodes=1 --nproc-per-node=4 main.py --distributed --wandb
    opt = TrainOptions().parse()
    run(opt) 
    