import os.path, glob
import torchvision.transforms as transforms
from data.base_dataset import BaseDataset, get_transform
from data.image_folder import make_dataset
from PIL import Image
import random

class UnalignedDataset(BaseDataset):
    def __init__(self, opt):
        super(UnalignedDataset, self).__init__()
        self.opt = opt
        self.transform = get_transform(opt)

        datapath = os.path.join(opt.dataroot, opt.phase, '*')  # root/phase/A, root/phase/B # phase determines whether train/ test
        self.dirs = sorted(glob.glob(datapath))

        self.paths = [sorted(make_dataset(d)) for d in self.dirs] # [A, B] 
        self.sizes = [len(p) for p in self.paths] # count for size of the images. A, B

    def load_image(self, dom, idx): 
        # A, B -> 0 , 1
        path = self.paths[dom][idx]
        img = Image.open(path).convert('RGB')
        img = self.transform(img)
        return img

    def __getitem__(self, index):
        img_A = self.load_image(0,index%self.sizes[0])
    
        if not self.opt.isTrain: # test not shuffling
            img_B = self.load_image(1,index%self.sizes[1])
        else: # shuffle when training.
            img_B = self.load_image(1,random.randint(0,self.sizes[1]-1))  
        
        return img_A, img_B

    def __len__(self): # return bigger file
        return max(self.sizes)
        
    def name(self):
        return 'UnalignedDataset'


